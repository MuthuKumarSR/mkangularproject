import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtonThreeComponent } from './button-three.component';

describe('ButtonThreeComponent', () => {
  let component: ButtonThreeComponent;
  let fixture: ComponentFixture<ButtonThreeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ButtonThreeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ButtonThreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
