import { Component } from '@angular/core';

@Component({
  selector: 'app-button-three',
  standalone: true,
  imports: [],
  templateUrl: './button-three.component.html',
  styleUrl: './button-three.component.css'
})
export class ButtonThreeComponent {

}
