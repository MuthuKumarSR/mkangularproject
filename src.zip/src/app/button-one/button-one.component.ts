import { Component } from '@angular/core';

@Component({
  selector: 'app-button-one',
  standalone: true,
  imports: [],
  templateUrl: './button-one.component.html',
  styleUrl: './button-one.component.css'
})
export class ButtonOneComponent {

}
