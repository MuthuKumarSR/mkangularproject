import { Component } from '@angular/core';

@Component({
  selector: 'app-button-two',
  standalone: true,
  imports: [],
  templateUrl: './button-two.component.html',
  styleUrl: './button-two.component.css'
})
export class ButtonTwoComponent {

}
