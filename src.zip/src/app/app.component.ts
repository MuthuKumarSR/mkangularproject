import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common'; 
import { ButtonOneComponent } from './button-one/button-one.component';
import { ButtonTwoComponent } from './button-two/button-two.component';
import { ButtonThreeComponent } from './button-three/button-three.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, ButtonOneComponent, ButtonTwoComponent, ButtonThreeComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-angular-app';
  currentTable: string = 'one';  // Default to Button One

  showTable(table: string) {
    this.currentTable = table;
  }
}
